<?php

include("database.php");
    
if (isset($_POST["register"])){
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";

    if($db->query($sql)){
       

    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="wrapper">
        <form action="register.php" method="POST">
            <h1> Daftar Akun</h1>
            <div class="input-box">
                <input type="text" placeholder="username"
                 name="username">
                <i class='bx bx-user'></i>
            </div>

            <div class="input-box">
                <input type="password" placeholder="password" name="password">
                <i class='bx bx-lock-alt'></i>
            </div>

            <div class="">
            </div>
            <button type="submit" href="index.php" class="btn" name="register">Daftar</a></button>

             <div class="register-link">
                <p><a href="index.php"> Kembali</a></p>
                </div>
        </form>

            
        </form>
    </div>
    
    
</body>
</html> 