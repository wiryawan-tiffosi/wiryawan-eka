
<?php

include ("database.php");

if(isset($_POST['index'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $db->query($sql);

    if($result->num_rows > 0){
        $data=$result->fetch_assoc();

        header("location:web.php");

    
}
}


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

    <div class="wrapper">
        <form action="index.php" method="POST">
            <h1> Log In</h1>
            <div class="input-box">
                <input type="text" placeholder="username"
name="username">
                <i class='bx bx-user'></i>
            </div>

            <div class="input-box">
                <input type="password" placeholder="password" name="password">
                <i class='bx bx-lock-alt'></i>
            </div>

            <div class="">
            </div>
            <button type="submit" name="index" class="btn">Login</button>

            <div class="register-link">
                <p>Tidak Punya Akun?<a href="register.php"> Daftar Akun</a></p>
                </div>
        </form>
    </div>
    
    
</body>
</html> 