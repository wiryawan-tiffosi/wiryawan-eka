<!DOCTYPE html>
<html>
<head>
    <title> Mamang Gunshop</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo.png" class="logo">
            <ul>
                <li><a href="Page2/Home.jpg">Home</a></li>
                <li><a href="#">List Senjata</a></li>
                <li><a href="#">Aksesoris</a></li>
                <li><a href="#">Cabang</a></li>
                <li><a href="#">About</a></li>
            </ul>
    </div>

    <div class="content">
        <h1> WIRYAWAN GUNSHOP</h1>
        <p> Tempat Jual Beli Senjata Ilegal Aman dan Terpercaya, <br>Alamat Toko: Rahasia.</p>
        <div>
            <a href="Page2/Log in.html">
            <button type="button"><span></span>ORDER</button>
            </a>
            <a href="Page2/Log in.html">
            <button type="button"><span></span>SELL</button> 
            </a>     
        </div>
    </div>



</body>
</html>