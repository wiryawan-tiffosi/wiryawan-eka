<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database_name = "database";

$db =mysqli_connect($hostname, $username, $password, $database_name);

if($db->connect_error){
echo "ERROR";
die("error");
}



?>